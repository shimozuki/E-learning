<?php
class Dashboard extends CI_Controller{

	function __construct(){
		parent::__construct();
	} 
	function index(){
		if ( $this->session->userdata('login') == 1) {
			$data['video'] = $this->query_builder->num_rows('t_video');
			$data['file'] = $this->query_builder->num_rows('t_sharing');
			$data['siswa'] = $this->query_builder->view_where_num_rows('t_user','user_level = 2');
			$data['evaluasi'] = $this->query_builder->num_rows('t_evaluasi');

			$data['peringkat'] = $this->db->query("SELECT b.user_name AS nama, SUM(a.hasil_nilai) AS nilai FROM t_hasil AS a JOIN t_user AS b ON a.hasil_siswa = b.user_id GROUP BY a.hasil_siswa ORDER BY nilai DESC LIMIT 5")->result_array();
			
			$data['dashboard'] = 'class="active"';
		    $data['title'] = 'Dashboard';
		    $this->load->view('v_template_admin/admin_header',$data);
		    $this->load->view('dashboard/dashboard');
 
		}
		else{
			redirect(base_url('login'));
		}
	} 
}