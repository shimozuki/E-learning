<?php
class Video extends CI_Controller{

	function __construct(){ 
		parent::__construct();
	}
	function index($page = 0){
		if ( $this->session->userdata('login') == 1) {
			$limit = 8;
			$mulai = $limit * $page; 

			//pagignation
			if ($page == 0) {
				$data['data'] = $this->db->query("SELECT * FROM t_album WHERE album_jenis = 'video' order by album_id desc LIMIT $limit")->result_array(); 
			}
			else{
				$data['data'] = $this->db->query("SELECT * FROM t_album WHERE album_jenis = 'video' order by album_id desc LIMIT $mulai,$limit")->result_array(); 
			}

			$x = $this->db->query("SELECT * FROM t_album WHERE album_jenis = 'video'")->num_rows();
			$data['paging'] = $x / 8; 

			$data['video'] = 'class="active"';
			$data['video_album'] = $this->db->query("SELECT * FROM t_album WHERE album_jenis = 'video'")->result_array();
			$data['title'] = 'Video';
			$data['limit'] = $limit;
			$data['row'] = $x;
			$this->load->view('v_template_admin/admin_header',$data);
			$this->load->view('video/index');
			$this->load->view('v_template_admin/admin_footer');
		}else{
			redirect(base_url('login'));
		}
	}
	function album(){

		$data = $this->input->post();

		if($_FILES['album_foto']['size'] <= 0){
			$this->session->set_flashdata('gagal','Foto tidak boleh lebih dari 2 MB');
			redirect(base_url('video'));
		}
		else{

			//config uplod foto
			  $config = array(
			  'upload_path' 	=> './assets/gambar/album',
			  'allowed_types' 	=> "gif|jpg|png|jpeg",
			  'overwrite' 		=> TRUE,
			  'max_size' 		=> "2048000",
			  'max_height' 		=> "10000",
			  'max_width' 		=> "20000"
			  );

			//upload foto
			$this->load->library('upload', $config);
			$this->upload->do_upload('album_foto');

			//replace Karakter name foto
			$name_foto = $_FILES['album_foto']['name'];
			$char = array('!', '&', '?', '/', '/\/', ':', ';', '#', '<', '>', '=', '^', '@', '~', '`', '{', '}', ' ');
	        $foto = str_replace($char, '_', $name_foto);
	        $char1 = array('[',']');
	        $foto1 = str_replace($char1, '', $foto);

	        //save database
			 $insert = array(
			 				'album_name' => $data['album_name'],
			 				'album_foto' => $foto1, 
			 				'album_tanggal' => date('Y-m-d'),
			 				'album_jenis' => 'video',
			 				);

			$this->db->insert('t_album',$insert);
			redirect(base_url('video'));
		}
	}
	function album_delete($id){

		//hapus album
		$this->db->where('album_id',$id);
		$this->db->delete('t_album');

		//hapus semua galery
		$this->db->where('video_album',$id);
		$this->db->delete('t_video');

		redirect(base_url('video'));
	}
	function upload($id = '',$name = ''){

		$data = $this->input->post();

		if($_FILES['video_foto']['size'] <= 0){
			$this->session->set_flashdata('gagal','Foto tidak boleh lebih dari 2 MB');
			redirect(base_url('video'));
		}
		else{

			//config uplod foto
			  $config = array(
			  'upload_path' 	=> './assets/gambar/video',
			  'allowed_types' 	=> "gif|jpg|png|jpeg",
			  'overwrite' 		=> TRUE,
			  'max_size' 		=> "2048000",
			  'max_height' 		=> "10000",
			  'max_width' 		=> "20000"
			  );

			//upload foto
			$this->load->library('upload', $config);
			$this->upload->do_upload('video_foto');

			//replace Karakter name foto
			$name_foto = $_FILES['video_foto']['name'];
			$char = array('!', '&', '?', '/', '/\/', ':', ';', '#', '<', '>', '=', '^', '@', '~', '`', '{', '}', ' ');
	        $foto = str_replace($char, '_', $name_foto);
	        $char1 = array('[',']');
	        $foto1 = str_replace($char1, '', $foto);

	        //hilangkan link
	        $replace_link = str_replace('https://www.youtube.com/watch?v=', '', $data['video_link']);

	        //save database
	        if($id > 0){
	        	$insert = array(
			 				'video_judul' => $data['video_name'],
			 				'video_foto' => $foto1, 
			 				'video_album' => $id,
			 				'video_link' => $replace_link,
			 				'video_tanggal' => date('Y-m-d'),

			 				);
	        }
		    else{
		    	$insert = array(
			 				'video_judul' => $data['video_name'],
			 				'video_foto' => $foto1, 
			 				'video_album' => $data['video_album'],
			 				'video_link' => $replace_link,
			 				'video_tanggal' => date('Y-m-d'),
			 				);
		    }

			$this->db->insert('t_video',$insert);
			
			//redirect
			if($id > 0){
				redirect(base_url('video/index_video/').$id.'/'.$name);
			}
			else{
				redirect(base_url('video'));
			}
		}
	}	
	function index_video($id,$name,$page = 0){
		$limit = 12;
		$mulai = $limit * $page;

		//pagignation
		if ($page == 0) {
			$data['data'] = $this->db->query("SELECT * FROM t_video WHERE video_album = '$id' order by video_id desc limit $limit")->result_array(); 
		}
		else{
			$data['data'] = $this->db->query("SELECT * FROM t_video WHERE video_album = '$id' order by video_id desc limit $mulai,$limit")->result_array();
		}

		$x = $this->db->query("SELECT * FROM t_video WHERE video_album = '$id'")->num_rows();
		$data['paging'] = $x / 8; 

		$data['video'] = 'class="active"';
		$data['title'] = str_replace('%20', ' ', $name);
		$data['id'] = $id;
		$data['limit'] = $limit;
		$data['row'] = $x;
		$this->load->view('v_template_admin/admin_header',$data);
		$this->load->view('video/video');
		$this->load->view('v_template_admin/admin_footer');
	}
	function upload_delete($id,$name,$id_halaman){

		$this->db->where('video_id',$id);
		$this->db->delete('t_video');

		redirect(base_url('video/index_video/').$id_halaman.'/'.$name);
	}
}