<?php
class Chat extends CI_Controller{

	function __construct(){
		parent::__construct();
	} 
	function index(){
		if ( $this->session->userdata('login') == 1) {
			$data['chat'] = 'class="active"';
		    $data['title'] = 'Chatting Room';
		    $data['data'] = $this->query_builder->view_join_order('t_chat','t_user','chat_id_user','user_id','chat_id');
		    $this->load->view('v_template_admin/admin_header',$data);
		    $this->load->view('chat/index');
		    $this->load->view('v_template_admin/admin_footer');

		}
		else{
			redirect(base_url('login')); 
		}
	} 
	function send(){
		$id = $this->session->userdata('id');
		if ($this->session->userdata('level') == 1) {
			//guru
			$set = array(
						'chat_id_user' => $id,
						'chat_text' => $_POST['text'],
						'chat_dari' => 'guru',
						'chat_tanggal' => date('Y-m-d'), 
					);
		}else{
			//siswa
			$set = array(
						'chat_id_user' => $id,
						'chat_text' => $_POST['text'],
						'chat_dari' => 'siswa',
						'chat_tanggal' => date('Y-m-d'), 
					);
		}
		$this->query_builder->add('t_chat',$set);
		redirect(base_url('chat'));
	}
}