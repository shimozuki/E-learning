<?php
class Sharing extends CI_Controller{

	function __construct(){
		parent::__construct();
	} 
	function index(){
		if ( $this->session->userdata('login') == 1) {
			$id = $this->session->userdata('id');
			$data['sharing'] = 'class="active"';
		    $data['title'] = 'Sharing File';

		    if ($this->session->userdata('level') == 1) {
		    	$data['data'] = $this->query_builder->view_join('t_sharing','t_user','sharing_user','user_id');
		    }else{
		    	$data['data'] = $this->query_builder->view_where_join('t_sharing','t_user','sharing_user','user_id','sharing_user ='.$id);
		    }

		    $this->load->view('v_template_admin/admin_header',$data);
		    $this->load->view('sharing/index');
		    $this->load->view('v_template_admin/admin_footer');

		}
		else{
			redirect(base_url('login'));
		}
	} 
	function add(){
		//upoload 
		$config = array(
		'upload_path' 	=> './assets/file',
		'allowed_types' 	=> "doc|docx|pdf",
		'overwrite' 		=> TRUE,
		// 'max_size' 		=> "2048000",
		// 'max_height' 		=> "10000",
		// 'max_width' 		=> "20000"
		);

		//upload foto
		$this->load->library('upload', $config);

		if ($this->upload->do_upload('sharing_file')) {

			//replace Karakter name foto
			$name_file = $_FILES['sharing_file']['name'];
			$char = array('!', '&', '?', '/', '/\/', ':', ';', '#', '<', '>', '=', '^', '@', '~', '`', '{', '}', ' ','-');
			$file = str_replace($char, '_', $name_file);
			$char1 = array('[',']');
			$file1 = str_replace($char1, '', $file);

			$set = array(
							'sharing_file' => $file1, 
							'sharing_user' => $this->session->userdata('id'), 
							'sharing_deskripsi' => $_POST['sharing_deskripsi'],
							'sharing_tanggal'	=> date('Y-m-d'),
						);
			$this->query_builder->add('t_sharing',$set);

			$this->session->set_flashdata('success','Data berhasil di tambah');
			redirect(base_url('sharing'));
		}else{
			$this->session->set_flashdata('gagal','Type file tidak sesuai');
			redirect(base_url('sharing'));
		}
	}
	function delete($id){
		$this->query_builder->delete('t_sharing','sharing_id ='.$id);
		$this->session->set_flashdata('success','Data berhasil di hapus');
		redirect(base_url('sharing'));
	}
	function update($id){
		$set = array( 
						'sharing_deskripsi' => $_POST['sharing_deskripsi'],
					);
		$this->query_builder->update('t_sharing',$set,'sharing_id ='.$id);

		$this->session->set_flashdata('success','Data berhasil di rubah');
		redirect(base_url('sharing'));
	}
}