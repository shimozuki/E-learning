<?php
class Siswa extends CI_Controller{

	function __construct(){
		parent::__construct();
	} 
	function index(){
		if ( $this->session->userdata('login') == 1) {
			$data['siswa'] = 'class="active"';
		    $data['title'] = 'Data Siswa';
		    $data['data'] = $this->query_builder->view_where('t_user','user_level = 2');

		    $this->load->view('v_template_admin/admin_header',$data);
		    $this->load->view('siswa/index');
		    $this->load->view('v_template_admin/admin_footer');

		}
		else{
			redirect(base_url('login'));
		}
	} 
	function add(){ 
		$x = $_POST['user_email'];
		$cek = $this->query_builder->view_where_num_rows('t_user','user_email ='.$x);

		if ($cek > 0) {
			$this->session->set_flashdata('gagal','NIM/NISN sudah di gunakan !!');
			redirect(base_url('siswa'));
		}else{
			$cek = $this->db->query("SELECT * FROM t_user order by user_id desc limit 1")->row_array();
			$id = $cek['user_id']+1;
			$set = array(
							'user_id' => $id,
							'user_name' => $_POST['user_name'], 
							'user_email' => $x, 
							'user_password' => md5($x),
							'user_tanggal'	=> date('Y-m-d'),
							'user_level'	=> 2, 
						);
			$this->query_builder->add('t_user',$set);

			$set1 = array('detail_id_user' => $id);
			$this->query_builder->add('t_detail_user',$set1);

			$this->session->set_flashdata('success','Data berhasil di tambah');
			redirect(base_url('siswa'));
		}
	}
	function delete($id){
		$this->query_builder->delete('t_user','user_id ='.$id);
		$this->query_builder->delete('t_detail_user','detail_id ='.$id);
		$this->query_builder->delete('t_chat','chat_id_user ='.$id);
		$this->query_builder->delete('t_hasil','hasil_siswa ='.$id);
		$this->query_builder->delete('t_sharing','sharing_user ='.$id);
		$this->session->set_flashdata('success','Data berhasil di hapus');

		redirect(base_url('siswa'));
	}
	function update($id){
		$x = $_POST['user_email'];
		$set = array(
						'user_name' => $_POST['user_name'], 
						'user_email' => $x, 
						'user_password' => md5($x),
						'user_tanggal'	=> date('Y-m-d'),
						'user_level'	=> 2, 
					);
		$this->query_builder->update('t_user',$set,'user_id ='.$id);
		$this->session->set_flashdata('success','Data berhasil di rubah');
		redirect(base_url('siswa'));
	}
}