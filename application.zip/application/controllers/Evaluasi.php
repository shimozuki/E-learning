<?php
class Evaluasi extends CI_Controller{

	function __construct(){ 
		parent::__construct();
	} 
	function index(){ 
		if ( $this->session->userdata('login') == 1) {
			$data['data'] = $this->query_builder->view_order('t_evaluasi','evaluasi_id');
			$data['evaluasi'] = 'class="active"';
		    $data['title'] = 'Evaluasi';
		    $this->load->view('v_template_admin/admin_header',$data);
		    $this->load->view('evaluasi/index');
		    $this->load->view('v_template_admin/admin_footer',$data);

		}
		else{
			redirect(base_url('login')); 
		}
	} 
	function add(){
		$data['evaluasi'] = 'class="active"';
		$data['title'] = 'Evaluasi';

		$cek = $this->db->query("SELECT * FROM t_evaluasi order by evaluasi_id DESC limit 1")->row_array();

		//generate idsoal
		if (@$cek == null) {
			$idsoal = 'SOAL1';
		}else{
			$num = str_replace('SOAL', '', $cek['evaluasi_id']);
			$i = $num + 1;
			$idsoal = 'SOAL'.$i;
		}
		
		$set = array(	
						'idsoal' => $idsoal,
						'judul' => $_POST['evaluasi_judul'],
						'jumlah' => $_POST['evaluasi_jumlah'],
						'bobot' => $_POST['evaluasi_bobot'],
						'timer' => $_POST['evaluasi_timer'], 
					);

		$this->load->view('v_template_admin/admin_header',$data);
		$this->load->view('evaluasi/add',$set);
		$this->load->view('v_template_admin/admin_footer');
	}
	function insert(){
		$jum = $_POST['evaluasi_jumlah'];
		$path = 'assets/img/soal';
		$idsoal = $_POST['evaluasi_id'];

		for ($i=1; $i < $jum+1 ; $i++) { 
			move_uploaded_file($_FILES['file'.$i]['tmp_name'], $path.'/'.$idsoal.'_'.$i.'.jpeg');
		}

		$set = array(
						'evaluasi_id' => $idsoal,
						'evaluasi_judul' => $_POST['evaluasi_judul'],
						'evaluasi_jumlah' => $jum,
						'evaluasi_pertanyaan' => json_encode($_POST),
						'evaluasi_bobot' => $_POST['evaluasi_bobot'],
						'evaluasi_timer' => $_POST['evaluasi_timer'],
						'evaluasi_tanggal' => date('Y-m-d'), 
					);

		$this->db->set($set);
		if ($this->db->insert('t_evaluasi')) {
			$this->session->set_flashdata('success','Data berhasil di tambah');
		}else{
			$this->session->set_flashdata('gagal','Data gagal di tambah');
		}

		redirect(base_url('evaluasi'));
	}
	function edit($id){
		$data['evaluasi'] = 'class="active"';
		$data['title'] = 'Evaluasi';
		$db = $this->db->query("SELECT * FROM t_evaluasi WHERE evaluasi_id = '$id'")->row_array();
		$set = array(	
						'idsoal' => $db['evaluasi_id'],
						'judul' => $db['evaluasi_judul'],
						'jumlah' => $db['evaluasi_jumlah'],
						'bobot' => $db['evaluasi_bobot'],
						'timer' => $db['evaluasi_timer'], 
					);


		//soal di pecah bentuk array//
		$soal = '['.$db['evaluasi_pertanyaan'].']';
		$v = str_replace(',"soal_pertanyaan', '},{"soal_pertanyaan', $soal);
		$data['soal'] = json_decode($v,true);

		$this->load->view('v_template_admin/admin_header',$data);
		$this->load->view('evaluasi/edit',$set);
		$this->load->view('v_template_admin/admin_footer');
	}
	function update($id){
		$jum = $_POST['evaluasi_jumlah'];
		$path = 'assets/img/soal';
		$idsoal = $_POST['evaluasi_id'];

		for ($i=1; $i < $jum+1 ; $i++) { 
			move_uploaded_file($_FILES['file'.$i]['tmp_name'], $path.'/'.$idsoal.'_'.$i.'.jpeg');
		}

		$set = array(
						'evaluasi_id' => $idsoal,
						'evaluasi_judul' => $_POST['evaluasi_judul'],
						'evaluasi_jumlah' => $jum,
						'evaluasi_pertanyaan' => json_encode($_POST),
						'evaluasi_bobot' => $_POST['evaluasi_bobot'],
						'evaluasi_timer' => $_POST['evaluasi_timer'] 
					);

		$this->db->where('evaluasi_id',$id);
		$this->db->set($set);
		if ($this->db->update('t_evaluasi')) {
			$this->session->set_flashdata('success','Data berhasil di edit');
		}else{
			$this->session->set_flashdata('gagal','Data gagal di edit');
		}

		redirect(base_url('evaluasi'));
	}
	function delete($id){
		$this->db->where('evaluasi_id',$id);

		if ($this->db->delete('t_evaluasi')) {
			$this->session->set_flashdata('success','Data berhasil di hapus');
		}else{
			$this->session->set_flashdata('gagal','Data gagal di hapus');
		}

		redirect(base_url('evaluasi'));
	}
	function kerjakan($id){
		$user = $this->session->userdata('id');
		$cek = $this->db->query("SELECT * FROM t_hasil where hasil_siswa = '$user' AND hasil_soal = '$id'")->num_rows();

		if ($cek == 1) {
			$this->session->set_flashdata('gagal','Soal sudah di kerjakan');
			redirect(base_url('evaluasi'));

		}else{
			$data['evaluasi'] = 'class="active"';
			$data['title'] = 'Evaluasi';
			$db = $this->db->query("SELECT * FROM t_evaluasi WHERE evaluasi_id = '$id'")->row_array();
			$set = array(	
							'idsoal' => $db['evaluasi_id'],
							'judul' => $db['evaluasi_judul'],
							'jumlah' => $db['evaluasi_jumlah'],
							'bobot' => $db['evaluasi_bobot'],
							'timer' => $db['evaluasi_timer'], 
						);


			//soal di pecah bentuk array//
			$soal = '['.$db['evaluasi_pertanyaan'].']';
			$v = str_replace(',"soal_pertanyaan', '},{"soal_pertanyaan', $soal);
			$data['soal'] = json_decode($v,true);

			$this->load->view('v_template_admin/admin_header',$data);
			$this->load->view('evaluasi/kerjakan',$set);
			$this->load->view('v_template_admin/admin_footer');
		}
	}
	function hasil($idsoal){
	  $jum = $_POST['evaluasi_jumlah'];

      //hitung nilai / bobot
      $sum = 0;
      for ($i=1; $i < $jum+1; $i++) { 
        
        if ($_POST['soal_kunci_jawaban'.$i] == md5($_POST['soal_jawaban'.$i])) {
          
          $sum +=count($_POST['soal_jawaban'.$i]);
        } 
      }
      //nilai
      $nilai = $sum * $_POST['evaluasi_bobot'];

		$set = array(
						'hasil_siswa' => $this->session->userdata('id'),
						'hasil_soal' => $idsoal,
						'hasil_pertanyaan' => json_encode($_POST),
						'hasil_nilai' => $nilai,
						'hasil_sisa_waktu' => $_POST['evaluasi_timer'],
						'hasil_status' => 0,
						'hasil_tanggal' => date('Y-m-d'), 
					);

		$this->db->set($set);
		if ($this->db->insert('t_hasil')) {
			$this->session->set_flashdata('success','Jawaban berhasil di kirim');
		}else{
			$this->session->set_flashdata('gagal','Jawaban gagal di kirim');
		}

		redirect(base_url('evaluasi'));
	}
	function hasil_view(){
		if ( $this->session->userdata('login') == 1) {
			$data['data'] = $this->query_builder->view_join_3('t_hasil','t_evaluasi','t_user','hasil_soal','evaluasi_id','user_id','hasil_siswa');
			$data['hasil'] = 'class="active"';
		    $data['title'] = 'Hasil Evaluasi';
		    $this->load->view('v_template_admin/admin_header',$data);
		    $this->load->view('evaluasi/hasil');
		    $this->load->view('v_template_admin/admin_footer',$data);

		}
		else{
			redirect(base_url('login')); 
		}
	}
	function hasil_delete($id){
		$this->db->where('hasil_id',$id);

		if ($this->db->delete('t_hasil')) {
			$this->session->set_flashdata('success','Data berhasil di hapus');
		}else{
			$this->session->set_flashdata('gagal','Data gagal di hapus');
		}

		redirect(base_url('evaluasi/hasil_view'));
	}
}