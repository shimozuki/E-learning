

    <!-- Main content --> 
    <section class="content">

    <?php if ($this->session->flashdata('sukses')): ?>
      <div class="alert alert-success alert-dismissible">
         <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
        <i class="icon fa fa-check"></i>
        <?php echo $this->session->flashdata('sukses'); ?>
      </div>
    <?php endif ?>

      <!-- Default box -->
      <div class="box">
        <div class="box-header with-border">

          <?php if ($this->session->userdata('level') == 1): ?>
            <div align="left">
                <button class="btn btn-success" data-toggle="modal" data-target="#modal-galery"><i class="fa fa-plus"></i> Uplod Video</button>
              </div>
          <?php endif ?>

          <div class="box-tools pull-right">
            <button type="button" class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip" title="Collapse">
              <i class="fa fa-minus"></i></button>
            <button type="button" class="btn btn-box-tool" data-widget="remove" data-toggle="tooltip" title="Remove">
              <i class="fa fa-times"></i></button>
          </div>
        </div>
        <div class="box-body">

          <?php foreach ($data as $key): ?>
              <div class="col-sm-8 col-md-2" style="background-color: #ededed; padding-bottom: 1%; margin-bottom: 1%;">
                <h4 class="text-center btn-success" style="padding: 2%; color: white; width: 100%;"><?php echo $key['video_judul'] ?></h4>

                <a target="_blank" href="https://www.youtube.com/embed/<?php echo $key['video_link'] ?>"><img src="<?php echo base_url() ?>assets/gambar/video/<?php echo $key['video_foto'] ?>" style="width: 100%; height: 100px;"></a>

                <?php if ($this->session->userdata('level') == 1): ?>
                  <div style="margin-top: 4%;">
                  <a style="width: 100%;"><button data-toggle="modal" data-target="#delete<?php echo $key['video_id'] ?>" style="width: 100%;"><i class="fa fa-trash"></i></button></a>
                  </div>
                <?php endif ?>

              </div>

              <!--modal hapus-->
                    <div class="modal fade" id="delete<?php echo $key['video_id'] ?>">
                      <div class="modal-dialog" align="center">
                        <div class="modal-content" style="max-width: 300px;">
                          <div class="modal-header">
                              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span></button>
                              <h4>Confrimed ?</h4>
                            </div>
                          <div class="modal-body" align="center">
                             <a href="<?php echo base_url() ?>video/upload_delete/<?php echo $key['video_id'] ?>/<?php echo $title ?>/<?php echo $id ?>"><button class="btn btn-success" style="width: 49%;">Yes</button></a>
                             <button class="btn btn-danger" data-dismiss="modal" style="width: 49%;">No</button>
                          </div>
                        </div>
                      </div>
                     </div>

          <?php endforeach ?>
            </div>

            <div class="box-header with-border">
            <nav aria-label="Page navigation example">
              <ul class="pagination">
                
                <?php for ($i=0; $i < $paging ; $i++): ?>
                  <?php if($row > $limit): ?>
                    <li class="page-item"><a class="page-link" href="<?php echo base_url() ?>galery/index_galery/<?php echo $id; ?>/<?php echo $title; ?>/<?php echo $i; ?>"><?php echo $i+1; ?></a></li>
                  <?php endif ?>
                <?php endfor ?>
                
              </ul>
            </nav>
          </div>

          </div>
          <!-- /.box -->
      </div>


 <div class="modal fade" id="modal-galery">
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Upload video</h4>
              </div>
              <div class="modal-body">
                <form role="form" method="post" action="<?php echo base_url() ?>video/upload/<?php echo $id.'/'.$title; ?>" enctype="multipart/form-data">
                  <div class="box-body">
                    <div class="form-group">
                      <label>Video name</label>
                      <input type="text" name="video_name" class="form-control" placeholder="Enter foto name : max 10 karakter" required="" maxlength="10">
                    </div>
                    <div class="form-group">
                      <label>Link youtube</label>
                      <input type="text" name="video_link" class="form-control" placeholder="Enter link youtube" required="">
                    </div>
                    <div class="form-group">
                      <label for="exampleInputFile">Sampul input</label>
                      <input required="" type="file" id="exampleInputFile" name="video_foto" required="" accept="image/*">
                    </div>
                  </div>
                  <!-- /.box-body -->

                  <div class="box-footer">
                    <button type="submit" class="btn btn-primary">Submit</button>
                     <button type="reset" class="btn btn-danger">Reset</button>
                  </div>
                </form>
              </div>
            </div>
            <!-- /.modal-content -->
          </div>
          <!-- /.modal-dialog -->
        </div>
        <!-- /.modal -->