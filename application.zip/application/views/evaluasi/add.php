 
    <!-- Main content --> 
    <section class="content">

      <!-- Default box -->
      <div class="box">
        <div class="box-header with-border">

            <div align="left" > 
              <a href="<?php echo base_url('evaluasi'); ?>"><button class="btn btn-danger"><i class="fa fa-chevron-circle-left"></i> Back</button></a>
            </div>

          <div class="box-tools pull-right">
            <button type="button" class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip" title="Collapse">
              <i class="fa fa-minus"></i></button>
            <button type="button" class="btn btn-box-tool" data-widget="remove" data-toggle="tooltip" title="Remove">
              <i class="fa fa-times"></i></button>
          </div>
        </div>
        <div class="box-body">
         
         <form class="form-row" action="<?php echo base_url('evaluasi/insert') ?>" method="post" enctype="multipart/form-data">
           <div class="form-group col-md-12">
             <label>Judul Pertanyaan</label>
             <input readonly="" value="<?php echo $judul ?>" type="text" name="evaluasi_judul" class="form-control">
           </div>
           <div class="form-group col-md-3">
             <label>ID Soal</label>
             <input readonly="" value="<?php echo $idsoal ?>" type="text" name="evaluasi_id" class="form-control">
           </div>
           <div class="form-group col-md-3">
             <label>Bobot Jawaban / 1 soal</label>
             <input readonly="" value="<?php echo $bobot ?>" type="number" name="evaluasi_bobot" class="form-control">
           </div>

           <div class="form-group col-md-3">
             <label>Waktu Pengerjaan / menit</label>
             <input readonly="" value="<?php echo $timer ?>" type="time" name="evaluasi_timer" class="without_ampm form-control">
           </div>
           <div class="form-group col-md-3">
             <label>Jumlah Soal</label>
             <input readonly="" value="<?php echo $jumlah ?>" type="number" name="evaluasi_jumlah" class="form-control">
           </div>

           <!--soal-->
           <?php for ($i = 0; $i < $jumlah; $i++): ?> 

             <div class="form-group row">
              <div class="col-xs-12 col-lg-6">
                <div class="col-lg-1">
                  <label><?php echo $i+1; ?>.</label>
                  <br>
                </div>
                <div class="col-lg-11 form-group">
                  <textarea name="soal_pertanyaan<?php echo $i+1; ?>" class="form-control textarea" required="" style="margin: 0px; height: 181px;"></textarea>
                </div>
                <div class="col-lg-1"></div>
                <div class="col-lg-11 form-group">
                  <input type="file" required="" class="form-control" name="file<?php echo $i+1; ?>" accept="image/*" multiple="">
                  <input type="hidden" id="file1" name="gambar<?php echo $i+1; ?>" value="<?php echo $idsoal; ?>_<?php echo $i+1; ?>">
                </div>
              </div>
              <div class="col-xs-12 col-lg-6">
                <div class="col-lg-1"><label>A. </label>
              </div>
              <div class="col-lg-11 form-group">
                <input type="text" required="" class="form-control" name="a<?php echo $i+1; ?>">
              </div>
              <div class="col-lg-1"><label>B. </label></div>
              <div class="col-lg-11 form-group">
                <input type="text" required="" class="form-control" name="b<?php echo $i+1; ?>">
              </div><div class="col-lg-1"><label>C. </label></div>
              <div class="col-lg-11 form-group">
                <input type="text" required="" class="form-control" name="c<?php echo $i+1; ?>">
              </div>
              <div class="col-lg-1"><label>D. </label></div>
              <div class="col-lg-11 form-group">
                <input type="text" required="" class="form-control" name="d<?php echo $i+1; ?>">
              </div>
              <div class="col-lg-1"><label>Kunci</label></div>
              <div class="col-lg-3 form-group">
                <select class="form-control" name="soal_kunci_jawaban<?php echo $i+1; ?>" required="">
                  <option value="" hidden="">-- Pilih --</option>
                  <option value="A">A</option>
                  <option value="B">B</option>
                  <option value="C">C</option>
                  <option value="D">D</option>
                </select>
              </div>
            </div>
          </div>
          <!--end soal-->
        <?php endfor ?>
          <hr> 
          <button class="btn btn-success" type="submit"><i class="fa fa-check"></i> Simpan</button>
          <a href="<?php echo base_url().$this->uri->segment(1) ?>"><button type="button" class="btn btn-danger"><i class="fa fa-times"></i> Batal</button></a>
         </form>

        </div>

        
      </div>
      <!-- /.box -->
