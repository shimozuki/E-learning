
 
    <!-- Main content --> 
    <section class="content">

      <!-- Default box --> 
      <div class="box">
        <div class="box-header with-border">

           <!--  <div align="left" > 
              <a href="<?php echo base_url('evaluasi'); ?>"><button class="btn btn-success"><i class="fa fa-chevron-circle-left"></i> Back</button></a>
            </div> -->

          <div class="box-tools pull-right">
            <button type="button" class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip" title="Collapse">
              <i class="fa fa-minus"></i></button>
            <button type="button" class="btn btn-box-tool" data-widget="remove" data-toggle="tooltip" title="Remove">
              <i class="fa fa-times"></i></button>
          </div>
        </div>
        <div class="box-body">
         
         <form id="form" class="form-row" action="<?php echo base_url('evaluasi/hasil/').$idsoal ?>" method="post" enctype="multipart/form-data">

          <div class="col-lg-12" style="border-style: solid; border-width: 1px; margin-bottom: 2%; padding: 1%; border-color: #cccccc;">
           <div class="form-group col-md-6">
             <label>Judul Pertanyaan</label>
             <input readonly="" value="<?php echo $judul ?>" type="text" name="evaluasi_judul" class="form-control">
           </div>
           <!-- <div class="form-group col-md-3"> -->
             <!-- <label>ID Soal</label> -->
             <input readonly="" value="<?php echo $idsoal ?>" type="hidden" name="evaluasi_id" class="form-control">
           <!-- </div> -->
           <!-- <div class="form-group col-md-3"> -->
             <!-- <label>Bobot Jawaban / 1 soal</label> -->
             <input readonly="" value="<?php echo $bobot ?>" type="hidden" name="evaluasi_bobot" class="form-control">
          <!--  </div> -->

           <div class="form-group col-md-3">
             <label>Waktu Pengerjaan / menit</label>
             <input readonly="" id="timer" value="" type="text" name="evaluasi_timer" class="form-control">
           </div>
           <div class="form-group col-md-3">
             <label>Jumlah Soal</label>
             <input readonly="" value="<?php echo $jumlah ?>" type="number" name="evaluasi_jumlah" class="form-control">
           </div>
          </div>


           <!--soal-->
           <?php for ($i = 1; $i < $jumlah+1; $i++): ?> 

             <div class="col-lg-12" style="border-style: solid; border-width: 1px; margin-bottom: 2%; padding: 1%; border-color: #cccccc;">
              <div class="col-xs-12 col-lg-6">
                <div class="col-lg-1">
                  <label><?php echo $i; ?>.</label>
                  <br>
                </div>
                <div class="col-lg-11 form-group">
                  
                  <img style="width: 90%; margin-bottom: 1.5%;" src="<?php echo base_url('assets/img/soal/').$soal[$i]['gambar'.$i].'.jpeg' ?>">

                  <?php echo $soal[$i]['soal_pertanyaan'.$i] ?>

                  <input type="hidden" value="<?php echo $soal[$i]['soal_pertanyaan'.$i] ?>" name="soal_pertanyaan<?php echo $i; ?>">
                  
                </div>
                <div class="col-lg-1"></div>

              </div>
              <div class="col-xs-12 col-lg-6">
                <div class="col-lg-1"><label>A. </label>
              </div>
              <div class="col-lg-11 form-group">
                <?php echo $soal[$i]['a'.$i] ?>

                <input type="hidden" required="" class="form-control" name="a<?php echo $i; ?>" value="<?php echo $soal[$i]['a'.$i] ?>">
              </div>
              <div class="col-lg-1"><label>B. </label></div>
              <div class="col-lg-11 form-group">
                <?php echo $soal[$i]['b'.$i] ?>

                <input type="hidden" required="" class="form-control" name="b<?php echo $i; ?>" value="<?php echo $soal[$i]['b'.$i] ?>">
              </div><div class="col-lg-1"><label>C. </label></div>
              <div class="col-lg-11 form-group">
                <?php echo $soal[$i]['c'.$i] ?>

                <input type="hidden" required="" class="form-control" name="c<?php echo $i; ?>" value="<?php echo $soal[$i]['c'.$i] ?>">
              </div>
              <div class="col-lg-1"><label>D. </label></div>
              <div class="col-lg-11 form-group">
                <?php echo $soal[$i]['d'.$i] ?>

                <input type="hidden" required="" class="form-control" name="d<?php echo $i; ?>" value="<?php echo $soal[$i]['d'.$i] ?>">
              </div>
                
              <input type="hidden" name="soal_kunci_jawaban<?php echo $i; ?>" value="<?php echo md5($soal[$i]['soal_kunci_jawaban'.$i]) ?>">
              
              <div class="col-lg-4 form-group">
                <select class="form-control" name="soal_jawaban<?php echo $i; ?>">
                  <option value="" hidden="">-- Jawaban --</option>
                  <option value="A">A</option>
                  <option value="B">B</option>
                  <option value="C">C</option>
                  <option value="D">D</option>
                </select>
              </div>
            </div>
          </div>

          <!--end soal-->
        <?php endfor ?>
          
          <button class="btn btn-success" type="submit"><i class="fa fa-send"></i> Kirim Pekerjaan</button>
         </form>

        </div>

        
      </div>
      <!-- /.box -->

<?php 
//convert waktu

$waktu = $timer * 60 / 60;

if (round($waktu) <= 0) {
  $menit = 0;
  $detik = $timer;
}else{
  $menit = $waktu;
  $detik = 0;
}


?>

<script type="text/javascript">
        $(document).ready(function() {

            var detik   = <?php echo $detik ?>; 
            var menit   = <?php echo $menit ?>;
              
            function hitung() {

                setTimeout(hitung,1000);
 
                /** Menampilkan Waktu Timer pada Tag #Timer di HTML yang tersedia */
                $('#timer').val(
                    menit + ' menit : ' + detik + ' detik'
                );
  
                /** Melakukan Hitung Mundur dengan Mengurangi variabel detik - 1 */
                detik --;
 
                if(detik < 0) {
                    detik = 59;
                    menit --;

                    if (menit < 0) {
                      //submit otomatis
                      $('#form').trigger('submit');
                    }
                } 
            }           
            /** Menjalankan Function Hitung Waktu Mundur */
            hitung();
      }); 
      // ]]>
    </script>
