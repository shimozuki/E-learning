
    <!-- Main content --> 
    <section class="content">

    <?php if ($this->session->flashdata('gagal')): ?>
      <div class="alert alert-danger alert-dismissible">
         <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
        <i class="icon fa fa-close"></i>
        <?php echo $this->session->flashdata('gagal'); ?>
      </div>
    <?php endif ?>
 
    <?php if ($this->session->flashdata('success')): ?>
      <div class="alert alert-success alert-dismissible">
         <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
        <i class="icon fa fa-check"></i>
        <?php echo $this->session->flashdata('success'); ?>
      </div>
    <?php endif ?>
 
      <!-- Default box -->
      <div class="box">
        <div class="box-header with-border">

          <?php if ($this->session->userdata('level') == 1): ?>
            <div align="left">
              <button class="btn btn-success" data-toggle="modal" data-target="#modal-album"><i class="fa fa-plus"></i> Tambah Soal</button>
            </div>
          <?php endif ?>

          <div class="box-tools pull-right">
            <button type="button" class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip" title="Collapse">
              <i class="fa fa-minus"></i></button>
            <button type="button" class="btn btn-box-tool" data-widget="remove" data-toggle="tooltip" title="Remove">
              <i class="fa fa-times"></i></button>
          </div>
        </div>
        <div class="box-body">
         
          <table id="example1" class="table table-bordered table-hover">
                <thead>
                <tr>
                  <th>Judul</th>
                  <th>Jumlah Soal</th>
                  <th>Bobot Nilai</th>
                  <th>Waktu Pengerjaan</th>
                  <th>Action</th>
                </tr>
                </thead>
                <tbody>

                <?php foreach ($data as $key): ?>
                                  
                  <tr>
                    <td><?php echo $key['evaluasi_judul'] ?></td>
                    <td><?php echo $key['evaluasi_jumlah'] ?></td>
                    <td><?php echo $key['evaluasi_bobot'] ?></td>
                    <td style="width: 20%;"><?php echo $key['evaluasi_timer'] ?></td>
                    <td <?= ($this->session->userdata('level') == 1)? 'style="width: 50px;"':'style="width: 20px;"' ?> >
                      <div style="width: 50px;">

                      <?php if ($this->session->userdata('level') == 2): ?>
                        <a href="<?php echo base_url('evaluasi/kerjakan/'.$key['evaluasi_id']) ?>"><button class="btn btn-xs btn-success"><i class="fa fa-pencil"></i></button></a>
                       <?php endif ?>

                      <?php if ($this->session->userdata('level') == 1): ?>
                        <a href="<?php echo base_url('evaluasi/edit/').$key['evaluasi_id'] ?>"><button class="btn btn-xs btn-primary"><i class="fa fa-edit"></i></button></a>

                        <button class="btn btn-xs btn-danger" data-toggle="modal" data-target="#modalHapus<?php echo $key['evaluasi_id'] ?>"><i class="fa fa-trash"></i></button>
                      <?php endif ?>

                      </div>
                    </td>
                  </tr>


                  <!--modal hapus-->
                      <div class="modal fade" id="modalHapus<?php echo $key['evaluasi_id'] ?>">
                        <div class="modal-dialog" align="center">
                          <div class="modal-content" style="max-width: 300px;">
                            <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                  <span aria-hidden="true">&times;</span></button>
                                <h4>Confirmed ?</h4>
                              </div>
                            <div class="modal-body" align="center">
                               <a href="<?php echo base_url() ?>evaluasi/delete/<?php echo $key['evaluasi_id'] ?>"><button class="btn btn-success" style="width: 49%;">Yes</button></a>
                               <button class="btn btn-danger" data-dismiss="modal" style="width: 49%;">No</button>
                            </div>
                          </div>
                        </div>
                       </div> 
                
                <?php endforeach ?>

                </tfoot>
              </table>

        </div>

        
      </div>
      <!-- /.box -->

      <div class="modal fade" id="modal-album">
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Tambah Soal Baru</h4>
              </div>
              <div class="modal-body">
                <form role="form" method="post" action="<?php echo base_url() ?>evaluasi/add" enctype="multipart/form-data">
                  <div class="box-body">

                    <div class="form-group">
                      <label>Judul</label>
                      <input required="" type="text" name="evaluasi_judul" class="form-control">
                    </div>

                    <div class="form-group">
                      <label>Bobot <small class="text-danger">* nilai 1 soal x jml soal</small></label>
                      <input required="" type="number" name="evaluasi_bobot" class="form-control">
                    </div>

                    <div class="form-group">
                      <label>Timer / Menit</label>
                      <input required="" type="number" name="evaluasi_timer" class=" form-control" value="">
                    </div>
                    
                    <div class="form-group">
                      <label>Jumlah</label>
                      <input required="" type="text" name="evaluasi_jumlah" class="form-control">
                    </div>

                  </div>
                  <!-- /.box-body -->

                  <div class="box-footer">
                    <button type="submit" class="btn btn-primary">Submit</button>
                     <button type="reset" class="btn btn-danger">Reset</button>
                  </div>
                </form>
              </div>
            </div>
            <!-- /.modal-content -->
          </div>
          <!-- /.modal-dialog -->
        </div>
        <!-- /.modal -->
