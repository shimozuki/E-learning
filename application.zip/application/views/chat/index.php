
    <!-- Main content --> 
    <section class="content">

    <?php if ($this->session->flashdata('gagal')): ?>
      <div class="alert alert-danger alert-dismissible">
         <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
        <i class="icon fa fa-close"></i>
        <?php echo $this->session->flashdata('gagal'); ?>
      </div>
    <?php endif ?>

    <?php if ($this->session->flashdata('success')): ?>
      <div class="alert alert-success alert-dismissible">
         <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
        <i class="icon fa fa-check"></i>
        <?php echo $this->session->flashdata('success'); ?>
      </div>
    <?php endif ?>

      <!-- Default box -->
      <div class="box">
        <div class="box-header with-border">

          <div class="box-tools pull-right">
            <button type="button" class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip" title="Collapse">
              <i class="fa fa-minus"></i></button>
            <button type="button" class="btn btn-box-tool" data-widget="remove" data-toggle="tooltip" title="Remove">
              <i class="fa fa-times"></i></button>
          </div>
          <br/>

        </div>
        <div class="box-body">
          <div class="pre-scrollable form-group col-lg-12">
                  <!-- start message-->

                <?php foreach ($data as $key): ?>
                    
                  <?php if ($key['chat_dari'] == 'siswa'): ?>
                      
                    <!-- Message. Default to the left -->
                    <div class="direct-chat-msg">
                      <div class="direct-chat-info clearfix">
                        <span class="direct-chat-name pull-left"><?php echo $key['user_name'] ?></span>
                        <span class="direct-chat-timestamp pull-right"><?php echo $key['chat_tanggal'] ?></span>
                      </div>
                      <!-- /.direct-chat-info -->
                      <?php if (@$key['user_foto']): ?>
                        <img class="direct-chat-img" src="<?php echo base_url('assets/gambar/user/'.$key['user_foto']) ?>" alt="message user image">
                      <?php else: ?>
                        <img class="direct-chat-img" src="<?php echo base_url('assets/gambar/user/no.jpg') ?>" alt="message user image">
                      <?php endif ?>
                      <!-- /.direct-chat-img -->
                      <div class="direct-chat-text">
                        <?php echo $key['chat_text'] ?>
                      </div>
                      <!-- /.direct-chat-text -->
                    </div>

                  <?php endif ?>

                  <?php if ($key['chat_dari'] == 'guru'): ?>
                    <!-- Message to the right -->
                    <div class="direct-chat-msg right">
                      <div class="direct-chat-info clearfix">
                        <span class="direct-chat-name pull-right"><?php echo $key['user_name'] ?></span>
                        <span class="direct-chat-timestamp pull-left"><?php echo $key['chat_tanggal'] ?></span>
                      </div>
                      <!-- /.direct-chat-info -->
                      <?php if (@$key['user_foto']): ?>
                        <img class="direct-chat-img" src="<?php echo base_url('assets/gambar/user/'.$key['user_foto']) ?>" alt="message user image">
                      <?php else: ?>
                        <img class="direct-chat-img" src="<?php echo base_url('assets/gambar/user/no.jpg') ?>" alt="message user image">
                      <?php endif ?>
                      <!-- /.direct-chat-img -->
                      <div class="direct-chat-text">
                        <?php echo $key['chat_text'] ?>
                      </div>
                      <!-- /.direct-chat-text -->
                    </div>

                  <?php endif ?>

                  <?php endforeach ?>
                    <!--end message-->

                  </div>

                  <!-- /.direct-chat-pane -->
                </div>
              </div>
                <!-- /.box-body -->
                <div class="box-footer" style="box-shadow: 0 1px 5px 0 rgba(0, 0, 0, 0.2), 0 3px 17px 0 rgba(0, 0, 0, 0.19);">
                  <form action="<?php echo base_url('chat/send') ?>" method="post">
                    <div class="input-group">
                      <input required="" type="text" name="text" placeholder="Type Message ..." class="form-control">
                      <span class="input-group-btn">
                            <button type="submit" class="btn btn-warning btn-flat">Send</button>
                          </span>
                    </div>
                  </form>
                

        </div>

        
      </div>
      <!-- /.box -->


  